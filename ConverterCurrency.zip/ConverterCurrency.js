function convert() {
    const amount = document.getElementById("amount").value;
    const fromCurrency = document.getElementById("fromCurrency").value;
    const toCurrency = document.getElementById("toCurrency").value;

    if (amount === "" || isNaN(amount)) {
        resultElement.textContent = "Please enter a valid amount.";
        return;
    }

    var url = "https://api.exchangerate-api.com/v4/latest/" + fromCurrency;

    fetch(url)
        .then(function (response) {
            return response.json();
        })

        .then(function (data) {
            var rate = data.rates[toCurrency];
            var convertedAmount = amount * rate;
            document.getElementById("result").innerHTML = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
        })

}