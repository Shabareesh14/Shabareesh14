const exchangeRates = {
    IDR: { IDR: 1, USD: 0.000063, INR: 0.005347, EUR: 0.000060, GBP: 0.000050, OMR: 0.000024, KWD: 0.000019, JPY: 0.009824, AUD: 0.000097, NZD: 0.000107 },
    USD: { IDR: 39312557, USD: 1, INR: 84.40, EUR: 0.942, GBP: 0.784, OMR: 0.385, KWD: 0.307, JPY: 155.07, AUD: 1.532, NZD: 1.688 },
    INR: { IDR: 186.9, USD: 0.0118, INR: 1, EUR: 0.0110, GBP: 0.0091, OMR: 0.004, KWD: 0.003, JPY: 1.837, AUD: 0.0180, NZD: 0.020 },
    EUR: { IDR: 16748, USD: 1.061, INR: 89.55, EUR: 1, GBP: 0.832, OMR: 0.408, KWD: 0.326, JPY: 164.53, AUD: 1.626, NZD: 1.791 },
    GBP: { IDR: 20103, USD: 1.273, INR: 107.5, EUR: 1.200, GBP: 1, OMR: 0.490, KWD: 0.391, JPY: 197.59, AUD: 1.952, NZD: 2.150 },
    OMR: { IDR: 41000, USD: 2.597, INR: 219.2, EUR: 2.447, GBP: 2.038, OMR: 1, KWD: 0.798, JPY: 402.8, AUD: 3.980, NZD: 4.384 },
    KWD: { IDR: 51321, USD: 3.251, INR: 274.4, EUR: 3.064, GBP: 2.552, OMR: 1.251, KWD: 1, JPY: 504.24, AUD: 4.982, NZD: 5.488 },
    JPY: { IDR: 101.81, USD: 0.006, INR: 0.5443, EUR: 0.006, GBP: 0.005, OMR: 0.002, KWD: 0.001, JPY: 1, AUD: 0.009, NZD: 0.010 },
    AUD: { IDR: 10302, USD: 0.652, INR: 55.08, EUR: 0.614, GBP: 0.5122, OMR: 0.2512, KWD: 0.2007, JPY: 101.19, AUD: 1, NZD: 1.101 },
    NZD: { IDR: 9355, USD: 0.592, INR: 50.017, EUR: 0.558, GBP: 0.465, OMR: 0.228, KWD: 0.182, JPY: 91.86, AUD: 0.907, NZD: 1 },
};

function convert() {
    const amount = document.getElementById("amount").value;
    const fromCurrency = document.getElementById("fromCurrency").value;
    const toCurrency = document.getElementById("toCurrency").value;
    const resultElement = document.getElementById("result");

    if (amount === "" || isNaN(amount)) {
        resultElement.textContent = "Please enter a valid amount.";
        return;
    }

    const rate = exchangeRates[fromCurrency][toCurrency];
    const convertedAmount = (amount * rate).toFixed(2);
    resultElement.textContent = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
}